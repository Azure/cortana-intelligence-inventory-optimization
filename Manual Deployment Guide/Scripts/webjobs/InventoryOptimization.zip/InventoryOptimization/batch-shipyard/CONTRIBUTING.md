Contributing Code
-----------------

This project has adopted the
[Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/).
For more information see the
[Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/)
or contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any
additional questions or comments.

If you would like to contribute to this project, please view the
[Microsoft Contribution guidelines](https://azure.github.io/guidelines/).

If you would like to contribute recipes to this project, please follow
the general guidelines [here](docs/98-contributing-recipes.md).
