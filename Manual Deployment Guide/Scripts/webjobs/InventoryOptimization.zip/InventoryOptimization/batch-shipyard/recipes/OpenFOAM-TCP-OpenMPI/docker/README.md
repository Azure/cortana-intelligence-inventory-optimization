# Dockerfile for OpenFOAM-TCP-OpenMPI
You must agree to the [OpenFOAM license](http://openfoam.org/licence/)
prior to use.
