# Dockerfile for Torch-CPU
This image can be found on [Docker Hub](https://hub.docker.com/r/alfpark/torch/).

You must agree to the [Torch License](https://github.com/torch/torch7/blob/master/COPYRIGHT.txt)
prior to use.
