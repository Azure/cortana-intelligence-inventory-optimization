# Dockerfile for HPLinpack-Infiniband-IntelMPI
You must agree to the
[Intel Linpack License](https://software.intel.com/en-us/articles/intel-linpack-benchmark-download-license-agreement)
prior to use.
