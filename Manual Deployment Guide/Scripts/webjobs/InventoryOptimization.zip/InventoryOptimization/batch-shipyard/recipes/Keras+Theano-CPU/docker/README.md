# Dockerfile for Keras+Theano-CPU
This image can be found on [Docker Hub](https://hub.docker.com/r/alfpark/keras/).

You must agree to the following licenses prior to use:
* [Keras License](https://github.com/fchollet/keras/blob/master/LICENSE)
* [Theano License](https://github.com/Theano/Theano/blob/master/doc/LICENSE.txt)
