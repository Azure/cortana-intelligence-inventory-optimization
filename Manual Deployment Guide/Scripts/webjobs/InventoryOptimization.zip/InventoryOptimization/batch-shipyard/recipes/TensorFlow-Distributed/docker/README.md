# Dockerfile for TensorFlow-Distributed
This image can be found on [Docker Hub](https://hub.docker.com/r/alfpark/tensorflow/).

You must agree to the following licenses prior to use:
* [TensorFlow License](https://github.com/tensorflow/tensorflow/blob/master/LICENSE)
