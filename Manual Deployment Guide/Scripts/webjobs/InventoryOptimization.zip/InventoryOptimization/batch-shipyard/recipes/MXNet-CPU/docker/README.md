# Dockerfile for MXNet-CPU
This image can be found on [Docker Hub](https://hub.docker.com/r/alfpark/mxnet/).

You must agree to the following licenses prior to use:
* [MXNet license](https://github.com/dmlc/mxnet/blob/master/LICENSE)
* [R licenses](https://www.r-project.org/Licenses/)
* [R Intel MKL license](https://mran.revolutionanalytics.com/assets/text/mkl-eula.txt)
