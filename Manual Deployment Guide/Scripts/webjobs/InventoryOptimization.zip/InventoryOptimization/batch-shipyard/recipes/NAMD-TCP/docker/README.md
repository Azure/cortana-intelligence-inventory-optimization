# Dockerfile for NAMD-TCP
This image can be found on [Docker Hub](https://hub.docker.com/r/alfpark/namd/).

You must agree to the [NAMD license](http://www.ks.uiuc.edu/Research/namd/license.html)
prior to use.
