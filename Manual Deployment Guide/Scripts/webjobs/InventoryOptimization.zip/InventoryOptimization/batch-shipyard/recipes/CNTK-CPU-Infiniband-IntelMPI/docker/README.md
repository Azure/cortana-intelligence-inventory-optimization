# Dockerfile for CNTK-CPU-Infiniband-IntelMPI
This image can be found on [Docker Hub](https://hub.docker.com/r/alfpark/cntk/).

You must agree to the following licenses prior to use:
* [CNTK License](https://github.com/Microsoft/CNTK/blob/master/LICENSE.md)
* [CNTK 1-bit SGD License](https://github.com/microsoft/cntk/wiki/CNTK-1bit-SGD-License)
