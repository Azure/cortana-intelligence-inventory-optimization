# Dockerfile for OpenFOAM-Infiniband-IntelMPI
You must agree to the [OpenFOAM license](http://openfoam.org/licence/)
prior to use.
