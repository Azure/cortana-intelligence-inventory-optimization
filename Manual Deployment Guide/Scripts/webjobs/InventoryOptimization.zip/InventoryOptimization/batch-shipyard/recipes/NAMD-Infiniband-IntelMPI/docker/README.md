# Dockerfile for NAMD-Infiniband
You must agree to the [NAMD license](http://www.ks.uiuc.edu/Research/namd/license.html)
prior to use.
