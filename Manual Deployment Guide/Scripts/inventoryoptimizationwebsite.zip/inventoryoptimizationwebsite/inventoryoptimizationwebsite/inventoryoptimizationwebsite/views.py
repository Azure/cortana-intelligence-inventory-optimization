"""
// Copyright  Microsoft Corporation ("Microsoft").
//
// Microsoft grants you the right to use this software in accordance with your subscription agreement, if any, to use software 
// provided for use with Microsoft Azure ("Subscription Agreement").  All software is licensed, not sold.  
// 
// If you do not have a Subscription Agreement, or at your option if you so choose, Microsoft grants you a nonexclusive, perpetual, 
// royalty-free right to use and modify this software solely for your internal business purposes in connection with Microsoft Azure 
// and other Microsoft products, including but not limited to, Microsoft R Open, Microsoft R Server, and Microsoft SQL Server.  
// 
// Unless otherwise stated in your Subscription Agreement, the following applies.  THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT 
// WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL MICROSOFT OR ITS LICENSORS BE LIABLE 
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE SAMPLE CODE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
"""

from flask import request
import os
from datetime import datetime
from time import gmtime, strftime
from azure.mgmt.datalake.analytics.job import DataLakeAnalyticsJobManagementClient
from azure.mgmt.datalake.analytics.job.models import JobInformation, JobState, USqlJobProperties
from flask import render_template
from inventoryoptimizationwebsite import app
from flask import send_file
from azure.datalake.store import core, lib, multithread
import logging, getpass, pprint, uuid, time





# Deployment environment variables defined on Azure (pull in with os.environ). Update the WebApp server application settings with the key value for CLIENT_ID, 
# CLIENT_SECRET, DATALAKESTORE_NAME, TENANT_ID. You can get these details from the Application Settings of the previously deployed WebAPp server for this solution while following the manual instruction or 
# If this is a CIQS Automated deloyment, look for these parameter values in Application Settings for the Azure Functions in the deployed Resource Group
'''
client_id = os.environ.get('CLIENT_ID', "optionally place a default value for local dev here")
client_secret = os.environ.get('CLIENT_SECRET', "optionally place a default value for local dev here")
adl_name=os.environ.get('DATALAKESTORE_NAME')
tenant_id= os.environ.get('TENANT_ID')
'''

# Update the below variables with their value provided in manual intructions or 
# look for these parameter values in Application Settings for the Azure Functions in the deployed Resource Group.

adl_name = '<DATALAKESTORE_NAME>'
tenant_id = '<TENANT_ID>'
client_id = '<CLIENT_ID>'
client_secret = '<CLIENT_SECRET>'



remote_path = '/configuration/Test.xlsx'
fileName= os.path.realpath('./Test.xlsx')

#order Query result csv


@app.route('/', methods=['GET', 'POST'])
@app.route('/home', methods=['GET', 'POST'])
def home():
    """Renders the home page."""
    token = lib.auth(tenant_id=tenant_id, client_id=client_id, client_secret=client_secret)
    adls_file_system_client = core.AzureDLFileSystem(token, store_name=adl_name)
    order_list=[]   
    raw_list = adls_file_system_client.ls('/orders_demo/dynlotsizing')
    for order in raw_list:
        if "/orders_" in order:
            order_list.append(order[25:33])
    return render_template(
        'index.html',
        title='Home Page',
        option_list=order_list,
        year=datetime.now().year
    )

@app.route('/download', methods=['GET'])
def downloader():
    """Renders the contact page."""
   # send_file(file_name, as_attachment=True)
    token = lib.auth(tenant_id=tenant_id, client_id=client_id, client_secret=client_secret)
    adls_file_system_client = core.AzureDLFileSystem(token, store_name=adl_name)
    multithread.ADLDownloader(adls_file_system_client, lpath= fileName, rpath= remote_path,overwrite=True)
    return send_file(fileName,mimetype='text/xls', as_attachment=True)


@app.route('/upload',methods=['POST'])
def uploader():
    token = lib.auth(tenant_id=tenant_id, client_id=client_id, client_secret=client_secret)
    adls_file_system_client = core.AzureDLFileSystem(token, store_name=adl_name)
    try:
     file=request.files['file']
     file.save(fileName)       
     multithread.ADLUploader(adls_file_system_client, lpath=fileName , rpath= remote_path,overwrite=True)
     return "File uploaded successfully"
    except Exception as Argument:
     return "Cannot Upload the file", Argument

 
@app.route('/downloadOrders',methods=['POST'])
def orderDownloader():
    try:
        token = lib.auth(tenant_id=tenant_id, client_id=client_id, client_secret=client_secret)
        adls_file_system_client = core.AzureDLFileSystem(token, store_name=adl_name)
        #now = datetime.now().time()
        now = strftime("%Y-%m-%d-%H%M", gmtime())
        outputFile='Order_Result{}.csv'.format(now)
        orderRemote_path = '/orderQueryResults/{}'.format(outputFile)
        orderFileName= os.path.realpath('./{}'.format(outputFile))
        orderList = request.form.getlist('orderList')
        startDate = request.form['startDate']
        endDate = request.form['endDate']
        startDate=datetime.strptime(startDate, "%m/%d/%Y").strftime("%Y-%m-%d")
        endDate=datetime.strptime(endDate, "%m/%d/%Y").strftime("%Y-%m-%d")
        #may need to recreate adl_token every time in case it expires
        #adl_token = lib.auth(tenant_id=adl_tenant_id, client_id=adl_client_id, client_secret=adl_client_secret)

        adla_job_client = DataLakeAnalyticsJobManagementClient(token,  'azuredatalakeanalytics.net')   

        #print(os.getcwd())
        adls_file_system_client = core.AzureDLFileSystem(token, store_name=adl_name)
        #if testing locally, update the below path to point to the USQLScript folder file
        usql_script = ''.join(open('inventoryoptimizationwebsite/USQLScript/GetOrder.txt','r').readlines())
        orderFiles = ''
        for order in orderList:
            orderFiles+='"/orders/s_Q_perishable/'+order+'.csv",'
            orderFiles+='"/orders/s_Q/'+order+'.csv",'
    
        #remove the last ,     
        orderFiles=orderFiles[:-1] 
    
        #replace the placeholder in U-SQL query with the values
        usql_script=usql_script.replace('loadCsvFiles',orderFiles)
        usql_script=usql_script.replace('startDate',startDate)
        usql_script=usql_script.replace('endDate',endDate)
        usql_script=usql_script.replace('Order_Result.csv',outputFile)
        jobId = str(uuid.uuid4())
        jobInfo =     JobInformation(
                          name='GetOrders',
                          type='USql',
                          degree_of_parallelism = 4, 
                          properties=USqlJobProperties(
                          script=usql_script))
    
        jobResult = adla_job_client.job.create(adl_name, jobId, jobInfo)
        while(jobResult.state != JobState.ended):
            print('Job is not yet done, waiting for 3 seconds. Current state: ' + jobResult.state.value)
            time.sleep(3)
            jobResult = adla_job_client.job.get(adl_name, jobId)

        multithread.ADLDownloader(adls_file_system_client, lpath= orderFileName, rpath= orderRemote_path,overwrite=True)
        return send_file(orderFileName,mimetype='text/csv', as_attachment=True)
    except Exception as Argument:
       return "Cannot Download the file", Argument
 